"""
Mock package for autogen classes used in testing.
"""