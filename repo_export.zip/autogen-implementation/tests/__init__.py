"""
Test package for the AutoGen implementation.
"""