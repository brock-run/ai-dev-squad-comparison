"""
Mock package for LangGraph classes used in testing.
"""