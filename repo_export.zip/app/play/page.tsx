import MemoryMountains from "@/components/MemoryMountains";

export default function PlayPage() {
    return <MemoryMountains />;
}