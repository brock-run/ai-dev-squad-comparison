"""
Mock package for CrewAI classes used in testing.
"""